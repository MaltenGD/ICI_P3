; v4 actualizada - 16 reglas: objetivos de lin y mapa de costes de la otra version

; hechos calculados en java: aqui solo comparamos medidas
(deftemplate MSPACMAN
 (slot distFantasma (type NUMBER) (default 10000))
 (slot distPPill (type NUMBER) (default 10000))
 (slot ultima (type SYMBOL) (default nada))
 (slot presaAnterior (type SYMBOL) (default ninguno))
 (slot objetivoAnterior (type INTEGER) (default -1))
 (slot pildoras (type INTEGER) (default 100))
 (slot poderes (type INTEGER) (default 0))
 (slot comida (type INTEGER) (default -1))
 (slot distComida (type NUMBER) (default 10000))
 (slot sinComer (type INTEGER) (default 0)))
(deftemplate FANTASMA
 (slot nombre (type SYMBOL)) (slot indice (type INTEGER) (default 0))
 (slot comestible (type SYMBOL)) (slot distancia (type NUMBER))
 (slot tiempo (type NUMBER)) (slot margen (type NUMBER) (default 10000))
 (slot nodo (type INTEGER) (default -1)))
(deftemplate OBJETIVO
 (slot tipo (type SYMBOL)) (slot nodo (type INTEGER))
 (slot distancia (type NUMBER)) (slot margen (type NUMBER))
 (slot cantidad (type INTEGER) (default 0))
 (slot fantasma (type SYMBOL) (default ninguno))
 (slot ventaja (type NUMBER) (default 0))
 (slot movimiento (type SYMBOL) (default NEUTRAL)))
(deftemplate SALIDA
 (slot indice (type INTEGER)) (slot movimiento (type SYMBOL))
 (slot nodo (type INTEGER)) (slot margen (type NUMBER))
 (slot visitas (type INTEGER) (default 0))
 (slot distComida (type NUMBER) (default 10000)))
(deftemplate PELIGRO)
(deftemplate ACOSO)
(deftemplate ACTION
 (slot id) (slot info (default "")) (slot priority (type INTEGER))
 (slot fantasma (type SYMBOL) (default ninguno))
 (slot nodo (type INTEGER) (default -1))
 (slot movimiento (type SYMBOL) (default NEUTRAL)))

 ; r1: siempre queda una propuesta para recoger comida
(defrule comer
 (MSPACMAN (comida ?n))
 => (assert (ACTION (id comer) (nodo ?n) (priority 10) (info "r1: comida por defecto"))))

 ; r2: encadenamos peligro antes de las reglas que consultan su ausencia
(defrule peligro
 (declare (salience 30))
 (MSPACMAN (distFantasma ?d&:(< ?d 20)))
 => (assert (PELIGRO)))

 ; r3: dos umbrales para no alternar cada turno
(defrule sigueElPeligro
 (declare (salience 30))
 (MSPACMAN (ultima huir) (distFantasma ?d&:(< ?d 30)))
 => (assert (PELIGRO)))

 ; r4: la accion de huida recorre el mapa de costes mirando los siguientes cruces
(defrule huir
 (PELIGRO)
 => (assert (ACTION (id huir) (priority 80)
  (info "r4: huir valorando los siguientes cruces"))))

 ; r5: conserva la idea del ejemplo, pero el objetivo debe superar el filtro
(defrule aLaPPill
 (PELIGRO)
 (MSPACMAN (distFantasma ?f))
 (OBJETIVO (tipo poder) (nodo ?n) (distancia ?p&:(< ?p ?f))
   (margen ?r&:(> ?r 3)) (movimiento ?m))
 => (assert (ACTION (id irAPPill) (nodo ?n) (movimiento ?m) (priority 90)
  (info "r5: poder alcanzable antes del peligro"))))

 ; r6: no basta con llegar antes del fin, dejamos tiempo para alcanzarlo en movimiento
(defrule cazar
 (not (PELIGRO))
 (FANTASMA (nombre ?g) (indice ?i) (comestible true) (nodo ?n)
   (distancia ?d) (tiempo ?t&:(> ?t (+ (* 2 ?d) 8))) (margen ?r&:(> ?r 3)))
 (not (FANTASMA (comestible true) (distancia ?d2&:(< ?d2 ?d))
   (tiempo ?t2&:(> ?t2 (+ (* 2 ?d2) 8))) (margen ?r2&:(> ?r2 3))))
 (not (FANTASMA (indice ?j&:(< ?j ?i)) (comestible true) (distancia ?d)
   (tiempo ?t3&:(> ?t3 (+ (* 2 ?d) 8))) (margen ?r3&:(> ?r3 3))))
 => (assert (ACTION (id perseguir) (fantasma ?g) (nodo ?n) (priority 60)
  (info (str-cat "r6: cazar a " ?g)))))

 ; r7: rematar puede ganar a huir, pero no ignora el margen del camino
(defrule rematar
 (FANTASMA (nombre ?g) (indice ?i) (comestible true) (nodo ?n)
   (distancia ?d) (tiempo ?t&:(> ?t (+ (* 2 ?d) 8))) (margen ?r&:(> ?r 3)))
 (not (FANTASMA (comestible true) (distancia ?d2&:(< ?d2 ?d))
   (tiempo ?t2&:(> ?t2 (+ (* 2 ?d2) 8))) (margen ?r2&:(> ?r2 3))))
 (not (FANTASMA (indice ?j&:(< ?j ?i)) (comestible true) (distancia ?d)
   (tiempo ?t3&:(> ?t3 (+ (* 2 ?d) 8))) (margen ?r3&:(> ?r3 3))))
 (test (< ?d 10))
 => (assert (ACTION (id perseguir) (fantasma ?g) (nodo ?n) (priority 85)
  (info (str-cat "r7: rematar a " ?g)))))

 ; r8: dos hechos distintos permiten detectar que no nos persigue solo uno
(defrule variosPerseguidores
 (declare (salience 40))
 (FANTASMA (indice ?i) (comestible false) (distancia ?a&:(< ?a 30)))
 (FANTASMA (indice ?j&:(> ?j ?i)) (comestible false) (distancia ?b&:(< ?b 30)))
 => (assert (ACOSO)))

 ; r9: con varios perseguidores no exigimos que el poder este mas cerca que ellos
(defrule poderConAcoso
 (ACOSO)
 (OBJETIVO (tipo poder) (nodo ?n) (distancia ?d&:(<= ?d 80))
   (margen ?r&:(> ?r 3)) (movimiento ?m))
 => (assert (ACTION (id irAPPill) (nodo ?n) (movimiento ?m) (priority 95)
  (info "r9: poder frente a varios perseguidores"))))

 ; r10: mantenemos un poder activo mientras su camino siga teniendo margen
(defrule mantenerPoder
 (MSPACMAN (ultima irAPPill) (objetivoAnterior ?n))
 (OBJETIVO (tipo anterior) (nodo ?n) (distancia ?d&:(<= ?d 90))
   (margen ?r&:(> ?r 3)) (movimiento ?m))
 => (assert (ACTION (id irAPPill) (nodo ?n) (movimiento ?m) (priority 92)
  (info "r10: mantener el poder elegido"))))

 ; r11: con diez pildoras o menos damos prioridad a acabar la recogida
(defrule terminarNivel
 (MSPACMAN (pildoras ?c&:(<= ?c 10)))
 (OBJETIVO (tipo comida) (nodo ?n) (margen ?r&:(> ?r 3)) (movimiento ?m))
 => (assert (ACTION (id comer) (nodo ?n) (movimiento ?m) (priority 70)
  (info "r11: terminar el nivel"))))

 ; r12: relaciona el cruce previsto con el tiempo del mismo fantasma
(defrule interceptar
 (not (PELIGRO))
 (OBJETIVO (tipo interceptar) (fantasma ?g) (nodo ?n) (movimiento ?m)
   (distancia ?d) (ventaja ?v&:(>= ?v 4)) (margen ?r&:(> ?r 3)))
 (FANTASMA (nombre ?g) (comestible true) (tiempo ?t&:(> ?t (+ (* 2 ?d) 8))))
 => (assert (ACTION (id interceptar) (fantasma ?g) (nodo ?n) (movimiento ?m)
  (priority 75) (info (str-cat "r12: interceptar a " ?g)))))

 ; r13: no perdemos tiempo con fantasmas comestibles que no podemos alcanzar
(defrule comerConPoder
 (not (PELIGRO))
 (exists (FANTASMA (comestible true)))
 (not (FANTASMA (comestible true) (distancia ?d)
   (tiempo ?t&:(> ?t (+ (* 2 ?d) 8))) (margen ?r&:(> ?r 3))))
 (OBJETIVO (tipo comida) (nodo ?n) (movimiento ?m) (margen ?s&:(> ?s 3)))
 => (assert (ACTION (id comer) (nodo ?n) (movimiento ?m) (priority 55)
  (info "r13: comida mientras las presas quedan lejos"))))

 ; r14: buscamos una zona con comida cuando ya no queda ninguna cerca
(defrule buscarZona
 (not (PELIGRO))
 (MSPACMAN (distComida ?d&:(> ?d 10)))
 (OBJETIVO (tipo zona) (nodo ?n) (cantidad ?c&:(>= ?c 3))
   (movimiento ?m) (margen ?r&:(> ?r 3)))
 => (assert (ACTION (id irZona) (nodo ?n) (movimiento ?m) (priority 35)
  (info "r14: zona con varias pildoras"))))

 ; r15: entre salidas seguras, menos visitas y despues cercania a comida
(defrule salirDelCircuito
 (MSPACMAN (sinComer ?t&:(>= ?t 120)))
 (SALIDA (indice ?i) (nodo ?n) (movimiento ?m) (margen ?r&:(> ?r 3))
   (visitas ?v) (distComida ?d&:(< ?d 10000)))
 (not (SALIDA (margen ?r2&:(> ?r2 3)) (visitas ?v2&:(< ?v2 ?v)) (distComida ?d2&:(< ?d2 10000))))
 (not (SALIDA (margen ?r3&:(> ?r3 3)) (visitas ?v) (distComida ?d3&:(< ?d3 ?d))))
 (not (SALIDA (margen ?r4&:(> ?r4 3)) (visitas ?v) (distComida ?d) (indice ?j&:(< ?j ?i))))
 => (assert (ACTION (id irZona) (nodo ?n) (movimiento ?m) (priority 82)
  (info "r15: salir de una zona sin comida"))))

; de la otra version: usar poder cercano con peligro, sin esperar al acoso
(defrule poderOportuno
 (FANTASMA (comestible false) (distancia ?f&:(<= ?f 30)))
 (OBJETIVO (tipo poder) (nodo ?n) (distancia ?d&:(<= ?d 25))
   (margen ?r&:(> ?r 3)) (movimiento ?m))
 => (assert (ACTION (id irAPPill) (nodo ?n) (movimiento ?m) (priority 88)
   (info "r16: poder cercano con peligro"))))
