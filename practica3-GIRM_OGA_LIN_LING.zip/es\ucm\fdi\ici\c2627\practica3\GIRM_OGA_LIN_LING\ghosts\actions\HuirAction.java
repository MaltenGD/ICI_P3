package es.ucm.fdi.ici.c2627.practica3.GIRM_OGA_LIN_LING.ghosts.actions;

import es.ucm.fdi.ici.rules.RulesAction;
import jess.Fact;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** huirConCriterio de GhostsV0Me: lejos de Ms. Pac-Man, prefiriendo cruces y evitando ppills. */
public class HuirAction implements RulesAction {

    private final GHOST yo;

    public HuirAction(GHOST yo) { this.yo = yo; }

    @Override
    public MOVE execute(Game game) {
        return LogicaFantasma.huir(game, yo);
    }

    @Override
    public void parseFact(Fact actionFact) { }

    @Override
    public String getActionId() { return "huir"; }   // el mismo id para los cuatro: cada motor tiene su mapa
}
